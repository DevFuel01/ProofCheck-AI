<?php

/**
 * ProofCheck AI - Targeted Pattern Test
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/ScamDetector.php';

$detector = new ScamDetector(GEMINI_API_KEY);

$testCases = [
    "Urgency/Fear" => "URGENT: Your account is blocked. Act now to prevent permanent closure.",
    "Impersonation" => "This is the CEO of your company. I need you to send a payment to this support team immediately.",
    "Investment" => "Guaranteed return! 500% profit in 24 hours with our new crypto investment platform.",
    "Sensitive Data" => "Verify your identity. Reply with your SSN, DOB, and the OTP code we just sent your phone."
];

echo "=== Targeted Scam Pattern Detection Test ===\n\n";

foreach ($testCases as $category => $text) {
    echo "--- Category: $category ---\n";
    echo "Message: \"$text\"\n";

    try {
        $result = $detector->analyze($text);
        echo "RESULT: " . strtoupper($result['risk_level']) . " (" . $result['risk_score'] . "/100)\n";
        echo "INDICATORS:\n";
        foreach ($result['indicators'] as $indicator) {
            echo "  • $indicator\n";
        }
        echo "PHRASES FOUND: " . implode(", ", $result['highlighted_phrases']) . "\n";
    } catch (Exception $e) {
        echo "ERROR: " . $e->getMessage() . "\n";
    }
    echo "\n";
}
