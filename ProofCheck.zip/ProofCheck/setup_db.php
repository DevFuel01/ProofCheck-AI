<?php
require_once 'config.php';

try {
    $pdo = getDBConnection();

    // Create reported_scams table
    $sql = "CREATE TABLE IF NOT EXISTS reported_scams (
        id INT AUTO_INCREMENT PRIMARY KEY,
        log_id INT,
        risk_level ENUM('low', 'medium', 'high'),
        scam_category VARCHAR(50),
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (log_id) REFERENCES analysis_logs(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

    $pdo->exec($sql);
    echo "<p style='color:green'>✅ Table 'reported_scams' created or already exists.</p>";

    // Ensure scam_category column exists in analysis_logs
    $stmt = $pdo->query("SHOW COLUMNS FROM analysis_logs LIKE 'scam_category'");
    if (!$stmt->fetch()) {
        $pdo->exec("ALTER TABLE analysis_logs ADD COLUMN scam_category VARCHAR(50) DEFAULT 'Other' AFTER risk_level");
        echo "<p style='color:green'>✅ Column 'scam_category' added to analysis_logs.</p>";
    } else {
        echo "<p>ℹ️ Column 'scam_category' already exists in analysis_logs.</p>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}
