<?php

/**
 * ProofCheck AI - Scam Detector
 * Hybrid detection engine combining rule-based and AI analysis
 */

require_once __DIR__ . '/AIAnalyzer.php';

class ScamDetector
{
    private $aiAnalyzer;
    private $rulePatterns;

    public function __construct($geminiApiKey = null)
    {
        $this->aiAnalyzer = new AIAnalyzer($geminiApiKey);
        $this->initializeRulePatterns();
    }

    /**
     * Initialize rule-based detection patterns
     */
    private function initializeRulePatterns()
    {
        $this->rulePatterns = [
            'urgency' => [
                'patterns' => [
                    '/\b(urgent|immediately|act now|limited time|expires|hurry|quick|asap|right now|don\'t wait)\b/i',
                    '/\b(within \d+ (hours?|minutes?|days?))\b/i',
                    '/\b(last chance|final (notice|warning)|account blocked)\b/i'
                ],
                'weight' => 15,
                'description' => 'Urgency tactics to pressure quick action'
            ],
            'financial_request' => [
                'patterns' => [
                    '/\b(send money|transfer funds|payment required|pay now|wire transfer)\b/i',
                    '/\b(otp|one.time.password|verification code|pin|cvv|card number)\b/i',
                    '/\b(bank (details|account)|credit card|debit card|routing number)\b/i',
                    '/\b(bitcoin|crypto|wallet address)\b/i'
                ],
                'weight' => 30,
                'description' => 'Requests for money or sensitive financial information'
            ],
            'impersonation' => [
                'patterns' => [
                    '/\b(verify (your )?account|confirm (your )?identity|update (your )?information)\b/i',
                    '/\b(suspended account|locked account|unusual activity|blocked account)\b/i',
                    '/\b(click here to|log.?in (here|now)|sign.?in (here|now))\b/i',
                    '/\b(dear (customer|user|member)|valued customer|ceo|support team|tech support|it department)\b/i'
                ],
                'weight' => 20,
                'description' => 'Impersonation of legitimate organizations'
            ],
            'authority_claims' => [
                'patterns' => [
                    '/\b(government|tax office|irs|inland revenue|hmrc)\b/i',
                    '/\b(police|law enforcement|fbi|interpol|court)\b/i',
                    '/\b(bank|paypal|amazon|microsoft|apple|google)\b/i',
                    '/\b(official|authorized|certified)\b/i'
                ],
                'weight' => 15,
                'description' => 'Claims of authority or official status'
            ],
            'threats' => [
                'patterns' => [
                    '/\b(legal action|lawsuit|arrest|warrant|prosecution)\b/i',
                    '/\b(fine|penalty|charges|consequences)\b/i',
                    '/\b(lose access|account (will be )?closed|terminated)\b/i',
                    '/\b(failure to (comply|respond|act))\b/i'
                ],
                'weight' => 25,
                'description' => 'Threatening language to create fear'
            ],
            'suspicious_urls' => [
                'patterns' => [
                    '/\b(bit\.ly|tinyurl|goo\.gl|ow\.ly|t\.co|rebrand\.ly|is\.gd)\b/i',
                    '/https?:\/\/\d+\.\d+\.\d+\.\d+/i',
                    '/\b[a-z0-9-]+\.(tk|ml|ga|cf|gq|club|top|xyz|link|info)\b/i',
                    '/https?:\/\/[a-z0-9-]*\.(com|net|org|edu|gov)-[a-z0-9]+\./i',
                    '/http:\/\/([a-z0-9-]+\.)+[a-z]{2,}/i', // Plain HTTP detection
                    '/\b(paypa[l1i]|g00gle|am[az]on|micr0s0ft|b[a4]nk|app[l1e]|netf[l1i]x)\b/i', // Brand lookalikes
                    '/(?:[a-z0-9-]+\.){2,}(com|net|org|biz|info)/i' // Deep subdomains (e.g. login.secure.bank.com.scams.net)
                ],
                'weight' => 25,
                'description' => 'Suspicious or shortened URLs'
            ],
            'too_good_to_be_true' => [
                'patterns' => [
                    '/\b(won|winner|prize|lottery|jackpot)\b/i',
                    '/\b(free (money|cash|gift|iphone|ipad))\b/i',
                    '/\b(congratulations|you\'ve been selected)\b/i',
                    '/\b(investment|profit|guaranteed return|crypto (returns?|profit))\b/i',
                    '/\b(\$\d{3,}|\d{3,} (dollars|pounds|euros)) (free|guaranteed)\b/i'
                ],
                'weight' => 20,
                'description' => 'Too-good-to-be-true offers'
            ],
            'personal_info_request' => [
                'patterns' => [
                    '/\b(social security|ssn|passport|driver\'s license)\b/i',
                    '/\b(date of birth|mother\'s maiden name)\b/i',
                    '/\b(password|username|login credentials)\b/i',
                    '/\b(confirm (your )?(email|phone|address))\b/i'
                ],
                'weight' => 25,
                'description' => 'Requests for personal information'
            ]
        ];
    }

    /**
     * Main analysis function - combines rule-based and AI detection
     */
    public function analyze($input, $type = 'text')
    {
        $startTime = microtime(true);

        // Step 1: Rule-based detection
        $ruleResults = $this->runRuleBasedDetection($input);

        // Step 2: AI/NLP analysis (if text)
        $aiResults = null;
        if ($type === 'text') {
            $aiResults = $this->aiAnalyzer->analyzeText($input);
        }

        // Step 3: Combine results
        $finalResults = $this->combineResults($ruleResults, $aiResults);

        // Calculate duration
        $duration = round((microtime(true) - $startTime) * 1000);
        $finalResults['analysis_duration_ms'] = $duration;

        return $finalResults;
    }

    /**
     * Run rule-based detection
     */
    private function runRuleBasedDetection($text)
    {
        $totalScore = 0;
        $detectedIndicators = [];
        $highlightedPhrases = [];

        foreach ($this->rulePatterns as $category => $config) {
            foreach ($config['patterns'] as $pattern) {
                if (preg_match_all($pattern, $text, $matches)) {
                    $totalScore += $config['weight'];
                    $detectedIndicators[] = $config['description'];

                    // Collect phrases to highlight
                    foreach ($matches[0] as $match) {
                        if (!in_array($match, $highlightedPhrases)) {
                            $highlightedPhrases[] = $match;
                        }
                    }
                    break; // Only count each category once
                }
            }
        }

        // Remove duplicates
        $detectedIndicators = array_unique($detectedIndicators);

        return [
            'score' => min($totalScore, 100),
            'indicators' => array_values($detectedIndicators),
            'highlighted_phrases' => $highlightedPhrases
        ];
    }

    /**
     * Combine rule-based and AI results
     */
    private function combineResults($ruleResults, $aiResults)
    {
        // If AI is unavailable, use rule-based only
        if ($aiResults === null || $aiResults['confidence'] === 0) {
            $finalScore = $ruleResults['score'];
            $indicators = $ruleResults['indicators'];
            $scamCategory = 'Other'; // Fallback for rule-only
            $explanation = $this->generateExplanation($ruleResults['indicators']);
            $highlightedPhrases = $ruleResults['highlighted_phrases'];
        } else {
            // Weighted combination: 60% AI, 40% rules
            $finalScore = round(($aiResults['confidence'] * 0.6) + ($ruleResults['score'] * 0.4));

            // Merge indicators
            $indicators = array_unique(array_merge(
                $ruleResults['indicators'],
                $aiResults['indicators']
            ));

            // Use AI results
            $explanation = $aiResults['explanation'];
            $scamCategory = $aiResults['scam_category'];

            // Merge highlighted phrases
            $highlightedPhrases = array_unique(array_merge(
                $ruleResults['highlighted_phrases'],
                $aiResults['suspicious_phrases']
            ));
        }

        // Determine risk level
        $riskLevel = $this->calculateRiskLevel($finalScore);

        // Generate recommendation
        $recommendation = $this->generateRecommendation($riskLevel, $finalScore);

        return [
            'risk_level' => $riskLevel,
            'risk_score' => $finalScore,
            'scam_category' => $scamCategory,
            'indicators' => array_values($indicators),
            'detailed_analysis' => $aiResults['detailed_analysis'] ?? [],
            'highlighted_phrases' => array_values($highlightedPhrases),
            'explanation' => $explanation,
            'recommendation' => $recommendation
        ];
    }

    /**
     * Calculate risk level from score
     */
    private function calculateRiskLevel($score)
    {
        if ($score >= 60) {
            return 'high';
        } elseif ($score >= 30) {
            return 'medium';
        } else {
            return 'low';
        }
    }

    /**
     * Generate explanation from indicators
     */
    private function generateExplanation($indicators)
    {
        if (empty($indicators)) {
            return "No significant scam indicators detected. This message appears to be legitimate.";
        }

        $count = count($indicators);
        return "Detected {$count} scam indicator" . ($count > 1 ? 's' : '') . ". " .
            "This message shows characteristics commonly found in scam attempts.";
    }

    /**
     * Generate actionable recommendation
     */
    private function generateRecommendation($riskLevel, $score)
    {
        switch ($riskLevel) {
            case 'high':
                return "⛔ **CRITICAL ACTION REQUIRED:** This is highly likely a scam. \n\n• **DO NOT** click any links or download attachments.\n• **IGNORE** and delete the message immediately.\n• **BLOCK** the sender to prevent further contact.\n• **REPORT** this message to your service provider or official anti-fraud authorities.";
            case 'medium':
                return "⚠️ **PROCEED WITH CAUTION:** Several suspicious patterns were detected.\n\n• **DO NOT** click links or provide sensitive information.\n• **VERIFY** the sender's identity through an official website or phone number.\n• **BLOCK** if the source cannot be verified.";
            case 'low':
                return "✓ **STAY VIGILANT:** This message appears relatively safe, but remember:\n\n• **NEVER** share passwords or OTPs.\n• **VERIFY** unexpected requests even if they appear to be from known contacts.";
            default:
                return "Unable to provide specific safety advice.";
        }
    }
}
