<?php

/**
 * ProofCheck AI - AI Analyzer
 * Gemini API integration for NLP-based scam detection
 */

class AIAnalyzer
{
    private $apiKey;
    private $apiEndpoint;

    public function __construct($apiKey)
    {
        $this->apiKey = $apiKey;
        $this->apiEndpoint = defined('GEMINI_API_ENDPOINT')
            ? GEMINI_API_ENDPOINT
            : 'https://generativelanguage.googleapis.com/v1/models/gemini-2.5-flash:generateContent';
    }

    /**
     * Analyze text using Gemini AI for scam patterns
     */
    public function analyzeText($text)
    {
        if (empty($this->apiKey)) {
            return $this->getFallbackAnalysis($text);
        }

        try {
            $prompt = $this->buildScamDetectionPrompt($text);
            $response = $this->callGeminiAPI($prompt);
            return $this->parseAIResponse($response);
        } catch (Exception $e) {
            error_log("AI Analysis failed: " . $e->getMessage());
            return $this->getFallbackAnalysis($text);
        }
    }

    /**
     * Build specialized prompt for scam detection
     */
    private function buildScamDetectionPrompt($text)
    {
        return "You are a scam detection expert. Analyze the following message for scam indicators.

MESSAGE TO ANALYZE:
\"\"\"
{$text}
\"\"\"

Analyze this message for:
1. Urgency tactics (limited time, act now, immediate action)
2. Fear-based language (threats, account suspension, legal action)
3. Requests for sensitive information (passwords, OTPs, PINs, bank details)
4. Impersonation attempts (claiming to be authority, bank, government)
5. Suspicious links or contact methods
6. Too-good-to-be-true offers
7. Poor grammar or spelling (common in scams)
8. Social engineering tactics

9. Identify the specific scam category from these options:
   - Phishing (Credential theft, fake login pages, impersonating organizations)
   - Investment scam (Crypto scams, guaranteed returns, 'get rich quick' schemes)
   - Impersonation scam (Claiming to be a friend, relative, or boss in distress)
   - Lottery scam (Prize winnings, inheritance notifications, unexpected windfalls)
   - Other (None of the above)

Respond ONLY in this exact JSON format:
{
    \"is_scam\": true,
    \"confidence\": 0-100,
    \"risk_level\": \"low\"|\"medium\"|\"high\",
    \"scam_category\": \"Phishing\"|\"Investment scam\"|\"Impersonation scam\"|\"Lottery scam\"|\"Other\",
    \"indicators\": [\"indicator 1\", \"indicator 2\"],
    \"detailed_analysis\": [\"specific reason why it's a scam\"],
    \"suspicious_phrases\": [\"phrase 1\", \"phrase 2\"],
    \"explanation\": \"Brief explanation of why this is/isn't a scam\"
}";
    }

    /**
     * Call Gemini API
     */
    private function callGeminiAPI($prompt)
    {
        $url = $this->apiEndpoint . '?key=' . $this->apiKey;

        $data = [
            'contents' => [
                [
                    'parts' => [
                        ['text' => $prompt]
                    ]
                ]
            ],
            'generationConfig' => [
                'temperature' => 0.2,
                'topK' => 40,
                'topP' => 0.95,
                'maxOutputTokens' => 1024,
            ]
        ];

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json'
        ]);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curlError = curl_error($ch);
        curl_close($ch);

        // Log detailed error information
        if ($httpCode !== 200) {
            $errorMsg = "API request failed with code: $httpCode";
            if ($curlError) {
                $errorMsg .= " | cURL Error: $curlError";
            }
            if ($response) {
                $errorMsg .= " | Response: " . substr($response, 0, 500);
            }
            error_log("Gemini API Error: " . $errorMsg);
            throw new Exception($errorMsg);
        }

        if ($curlError) {
            error_log("Gemini API cURL Error: " . $curlError);
            throw new Exception("cURL Error: $curlError");
        }

        return json_decode($response, true);
    }

    /**
     * Parse AI response and extract structured data
     */
    private function parseAIResponse($response)
    {
        // Log the raw response for debugging
        if (defined('DEBUG_MODE') && DEBUG_MODE) {
            error_log("Gemini API Raw Response: " . json_encode($response));
        }

        if (!isset($response['candidates'][0]['content']['parts'][0]['text'])) {
            // Log what we actually got
            error_log("Gemini API Response missing expected structure. Got: " . json_encode($response));
            throw new Exception("Invalid API response format");
        }

        $text = $response['candidates'][0]['content']['parts'][0]['text'];

        // Log the extracted text
        if (defined('DEBUG_MODE') && DEBUG_MODE) {
            error_log("Gemini API Extracted Text: " . $text);
        }

        // Extract JSON from response (handle markdown code blocks)
        $text = preg_replace('/```json\s*|\s*```/', '', $text);
        $text = trim($text);

        $data = json_decode($text, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("Failed to parse AI response JSON. Error: " . json_last_error_msg() . " | Text: " . substr($text, 0, 500));
            throw new Exception("Failed to parse AI response JSON");
        }

        return [
            'is_scam' => $data['is_scam'] ?? false,
            'confidence' => $data['confidence'] ?? 50,
            'risk_level' => $data['risk_level'] ?? 'medium',
            'scam_category' => $data['scam_category'] ?? 'Other',
            'indicators' => $data['indicators'] ?? [],
            'detailed_analysis' => $data['detailed_analysis'] ?? [],
            'suspicious_phrases' => $data['suspicious_phrases'] ?? [],
            'explanation' => $data['explanation'] ?? 'Unable to determine scam likelihood'
        ];
    }

    /**
     * Fallback analysis when AI is unavailable
     */
    private function getFallbackAnalysis($text)
    {
        return [
            'is_scam' => false,
            'confidence' => 0,
            'risk_level' => 'low',
            'scam_category' => 'None',
            'indicators' => ['AI analysis unavailable - using rule-based detection only'],
            'suspicious_phrases' => [],
            'explanation' => 'AI analysis is currently unavailable. Results based on rule-based detection only.'
        ];
    }
}
