<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/ScamDetector.php';

$detector = new ScamDetector();
$text = "Urgent: Your account is blocked. This is the CEO from support team. Guaranteed profit on investment. Provide your OTP and SSN.";
$result = $detector->analyze($text);

echo "Analysis for: \"$text\"\n\n";
echo "Risk Level: " . $result['risk_level'] . "\n";
echo "Score: " . $result['risk_score'] . "\n";
echo "Indicators found:\n";
foreach ($result['indicators'] as $ind) {
    echo "- $ind\n";
}
echo "\nPhrases matched:\n";
foreach ($result['highlighted_phrases'] as $phrase) {
    echo "- $phrase\n";
}
