# ProofCheck AI 🛡️

**Instantly detect scam messages, phishing links, and fraud attempts before you lose money.**

ProofCheck AI is a web-based scam detection system that uses a hybrid approach combining AI-powered NLP analysis with rule-based pattern matching to identify fraudulent messages, phishing attempts, and suspicious URLs.

![ProofCheck AI](https://img.shields.io/badge/Status-Demo%20Ready-success)
![PHP](https://img.shields.io/badge/PHP-7.4%2B-blue)
![License](https://img.shields.io/badge/License-MIT-green)

## 🌟 Features

### Core Functionality
- ✅ **Text Message Analysis** - Analyze SMS, WhatsApp, email content for scam indicators
- ✅ **URL Analysis** - Detect suspicious and phishing links
- ✅ **Real-time Detection** - Get instant results in under 5 seconds
- ✅ **Risk Scoring** - Clear Low/Medium/High risk classification
- ✅ **Phrase Highlighting** - Visual identification of suspicious content
- ✅ **Actionable Recommendations** - Clear guidance on what to do next
- ✅ **Scam Categorization** - Automatic identification of scam type (e.g. Phishing, Investment, Tech Support)

### Community & Analytics
- ✅ **Community Flagging** - Users can anonymously report scams to improve the ecosystem
- ✅ **Admin Dashboard** - Real-time analytics and platform usage statistics
- ✅ **Risk Distribution** - Visual breakdown of threat levels detected globally
- ✅ **Live Stats** - Tracking of total checks and successful reports

### Detection Capabilities
- 🤖 **AI/NLP Analysis** - Advanced language pattern detection using Gemini API
- ⚡ **Rule-Based Detection** - Fast pattern matching for known scam indicators
- 🎯 **Hybrid Approach** - Combines AI intelligence with rule-based speed
- 🔍 **Multi-Pattern Detection**:
  - Urgency tactics and pressure language
  - Financial information requests (OTP, PIN, bank details)
  - Impersonation attempts
  - Authority claims (government, banks, law enforcement)
  - Threatening language
  - Suspicious URLs and shortened links
  - Too-good-to-be-true offers
  - Personal information requests

### Privacy & Security
- 🔒 **Zero Message Storage** - Actual message content is never stored in the database
- 🕵️ **Anonymous Logging** - Only aggregate metadata (timestamp, risk level, category) is logged
- 🚫 **No Tracking** - No cookies, no IP logging, no user tracking
- ✅ **Privacy First** - Temporary processing only for core analysis

### User Experience
- 🎨 **Modern UI** - Premium dark mode design with glassmorphism
- 📱 **Fully Responsive** - Mobile-optimized layout with responsive hamburger menu
- ⚡ **Example Messages** - Expanded library of 9 pre-loaded scam examples for testing
- 💡 **One-Click Analysis** - Instant testing with pre-filled case studies

## 🚀 Quick Start

### Prerequisites
- **XAMPP** (or similar) with PHP 7.4+ and MySQL
- **Gemini API Key** (for AI analysis)
- Modern web browser

### Installation

1. **Clone/Copy to XAMPP**
   ```bash
   # Copy the ProofCheck folder to your XAMPP htdocs directory
   # Location: C:\xampp\htdocs\ProofCheck
   ```

2. **Setup Database**
   - Open phpMyAdmin: `http://localhost/phpmyadmin`
   - Import `database.sql` to create the schema and initial views.
   - Or use command line:
   ```bash
   mysql -u root -p < database.sql
   ```

3. **Configure Environment**
   - Copy `.env.example` to `.env` and add your **GEMINI_API_KEY**.
   ```env
   DB_HOST=localhost
   DB_NAME=proofcheck_db
   DB_USER=root
   DB_PASS=
   GEMINI_API_KEY=your_api_key_here
   ```

4. **Start XAMPP**
   - Start Apache and MySQL services
   - Navigate to: `http://localhost/ProofCheck`

## 📊 Admin Dashboard

Access the platform metrics at: `http://localhost/ProofCheck/admin`

The dashboard provides:
- **Platform Overview**: Total analyses performed vs total reports.
- **Threat Landscape**: Risk level distribution (High/Medium/Low).
- **Recent Activity**: Real-time view of latest scam detections.
- **Privacy Focus**: Dashboard emphasizes that no personal message content is viewable.

## 🏗️ Project Structure

```
ProofCheck/
├── admin/
│   └── index.php            # Analytics Dashboard
├── api/
│   ├── analyze.php          # Main analysis API endpoint
│   └── report.php           # Scam reporting API endpoint
├── assets/
│   ├── css/
│   │   └── style.css        # Modern UI & Mobile styles
│   └── js/
│       └── app.js           # Frontend logic & Menu Toggles
├── includes/
│   ├── AIAnalyzer.php       # AI integration logic
│   └── ScamDetector.php     # Hybrid detection engine
├── .env                     # App configuration
├── database.sql             # Full schema with reporting tables
└── index.php                # Main application page
```

## 🔧 Technical Details

### API Endpoints

#### POST `/api/analyze.php`
Performs hybrid scam analysis.
- **Response**: Returns `risk_level`, `risk_score`, `scam_category`, and `log_id`.

#### POST `/api/report.php`
Logs a community flag.
- **Request**: `{ "log_id": 123 }`
- **Privacy**: Anonymously links to the existing analysis log without storing new content.

### Mobile Optimization
- **Hamburger Menu**: Clean overlay navigation for smaller screens.
- **Auto-Closing**: Menu automatically closes after selecting a link.
- **Touch-Friendly**: Large buttons and example cards optimized for finger taps.

## 🧪 Testing

### Example Test Cases

**1. High Risk (Phishing):**
> Security Alert: Abnormal login on your Paypa1. Fix now: http://paypa1-security.com

**2. Medium Risk (Investment):**
> Urgently hiring! Earn up to $400 daily. Act now! Telegram @JobManager

**3. Low Risk (Legitimate):**
> Hi, just checking in for our meeting at 3 PM.

## 🤝 Future Enhancements
- [ ] Browser extension for real-time browsing protection.
- [ ] Advanced URL screenshots and domain WHOIS lookups.
- [ ] Machine learning model training on community-reported data.
- [ ] Multi-language support for international scam detection.

## 📝 License
MIT License - Free to use and modify for safety advocacy.

---

**Built with ❤️ for a safer internet**

🛡️ **ProofCheck AI** - Stop Scams Before They Stop You
