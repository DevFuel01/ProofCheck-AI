<?php

/**
 * ProofCheck AI - API Test Script
 * Use this to test if your Gemini API key is working
 */

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/includes/AIAnalyzer.php';

echo "=== ProofCheck AI - API Test ===\n\n";

// Check if API key is set
$apiKey = GEMINI_API_KEY;
if (empty($apiKey)) {
    echo "❌ ERROR: GEMINI_API_KEY is not set in .env file\n";
    echo "Please add your API key to the .env file:\n";
    echo "GEMINI_API_KEY=your_actual_api_key_here\n\n";
    exit(1);
}

echo "✓ API Key found (length: " . strlen($apiKey) . " characters)\n";
echo "✓ API Endpoint: " . GEMINI_API_ENDPOINT . "\n\n";

// Test message
$testMessage = "URGENT! Your bank account has been suspended. Click here immediately to verify.";
echo "Testing with message:\n\"$testMessage\"\n\n";

// Create analyzer
$analyzer = new AIAnalyzer($apiKey);

try {
    echo "Calling Gemini API...\n";
    $result = $analyzer->analyzeText($testMessage);

    echo "\n✓ SUCCESS! API Response:\n";
    echo "- Is Scam: " . ($result['is_scam'] ? 'Yes' : 'No') . "\n";
    echo "- Confidence: " . $result['confidence'] . "%\n";
    echo "- Risk Level: " . strtoupper($result['risk_level']) . "\n";
    echo "- Indicators: " . count($result['indicators']) . " found\n";

    if (!empty($result['indicators'])) {
        foreach ($result['indicators'] as $indicator) {
            echo "  • $indicator\n";
        }
    }

    echo "- Explanation: " . $result['explanation'] . "\n";

    if ($result['confidence'] === 0) {
        echo "\n⚠️ WARNING: Confidence is 0, which means AI analysis failed.\n";
        echo "The system is using rule-based detection only.\n";
    } else {
        echo "\n✓ AI analysis is working correctly!\n";
    }
} catch (Exception $e) {
    echo "\n❌ ERROR: " . $e->getMessage() . "\n\n";
    echo "Common issues:\n";
    echo "1. Invalid API key - check your .env file\n";
    echo "2. API key doesn't have access to Gemini 2.5 Flash\n";
    echo "3. Network/firewall blocking the request\n";
    echo "4. API quota exceeded\n\n";
    echo "Check the error log for more details.\n";
}

echo "\n=== Test Complete ===\n";
