/**
 * ProofCheck AI - Frontend Application
 * Handles user interactions and API communication
 */

// DOM Elements
const inputText = document.getElementById('inputText');
const charCount = document.getElementById('charCount');
const analyzeBtn = document.getElementById('analyzeBtn');
const loadingState = document.getElementById('loadingState');
const resultsPanel = document.getElementById('resultsPanel');
const analyzeAgainBtn = document.getElementById('analyzeAgainBtn');
const exampleCards = document.querySelectorAll('.example-card');
const detectedType = document.getElementById('detectedType');
const reportScamBtn = document.getElementById('reportScamBtn');
const reportStatus = document.getElementById('reportStatus');
const hamburger = document.getElementById('hamburger');
const navMenu = document.getElementById('navMenu');
const navLinks = document.querySelectorAll('.nav-link');

// State
let currentLogId = null;

// Example messages
const examples = {
    safe: "Hey! Just wanted to check if we are still on for dinner tonight at 7 PM? Let me know when you can!",
    url_scam: "Security Alert: Abnormal login detected on your Paypa1 account. Please secure your account immediately: http://paypa1-security-check.com/login",
    urgent: "URGENT! Your bank account has been suspended due to unusual activity. Click here immediately to verify your identity: bit.ly/verify123",
    prize: "Congratulations! You've won $5,000 in our lottery draw! To claim your prize, send us your bank details and a processing fee of $50. Limited time offer!",
    otp: "Dear customer, we need to verify your account. Please reply with the OTP code we just sent to your phone to avoid account suspension.",
    authority: "This is the IRS. You have unpaid taxes. Failure to respond within 48 hours will result in legal action and arrest warrant. Call immediately: 555-0123",
    delivery: "Your package delivery failed. Pay $3.99 shipping fee to reschedule: http://fedex-delivery-track.com/confirm. Your package will be returned if not claimed within 24 hours.",
    tech: "Microsoft Security Alert: We detected suspicious activity on your computer. Your system may be infected with malware. Call our certified technicians immediately at 1-800-SUPPORT to prevent data loss.",
    investment: "Urgently hiring! Part-time remote work. Earn up to $400 daily. No experience or interview required. Guaranteed income. Act now, limited spots! Reach us on Telegram @JobManager_Verify or visit: http://bit.ly/fast-job-now"
};

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    setupEventListeners();
    updateCharCount();
});

/**
 * Setup event listeners
 */
function setupEventListeners() {
    // Input character count
    inputText.addEventListener('input', updateCharCount);
    
    // Analyze button
    analyzeBtn.addEventListener('click', handleAnalyze);
    
    // Analyze again button
    analyzeAgainBtn.addEventListener('click', resetForm);
    
    // Example cards
    exampleCards.forEach(card => {
        card.addEventListener('click', handleExampleClick);
    });
    
    // Report scam button
    reportScamBtn.addEventListener('click', handleReportScam);
    
    // Hamburger Menu Toggle
    if (hamburger) {
        hamburger.addEventListener('click', toggleMenu);
    }
    
    // Close menu when clicking nav links
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            if (navMenu.classList.contains('active')) {
                toggleMenu();
            }
        });
    });
    
    // Enter key to analyze
    inputText.addEventListener('keydown', (e) => {
        if (e.ctrlKey && e.key === 'Enter') {
            handleAnalyze();
        }
    });
}

/**
 * Update character count
 */
function updateCharCount() {
    const text = inputText.value;
    const count = text.length;
    charCount.textContent = count;
    
    // Detect input type
    detectInputType(text);
    
    // Update color based on length
    if (count > 4500) {
        charCount.style.color = '#ef4444';
    } else if (count > 4000) {
        charCount.style.color = '#f59e0b';
    } else {
        charCount.style.color = '#94a3b8';
    }
}

/**
 * Smart auto-detection of input type
 */
function detectInputType(text) {
    if (!text.trim()) {
        detectedType.textContent = '';
        return 'text';
    }

    // URL detection patterns
    const urlPattern = /^(https?:\/\/)?([\da-z.-]+)\.([a-z.]{2,6})([\/\w .-]*)*\/?$/i;
    const commonUrlStarts = /^(https?:\/\/|www\.|[a-z0-9.-]+\.(com|org|net|edu|gov|io|co))/i;
    
    const isUrl = urlPattern.test(text.trim()) || commonUrlStarts.test(text.trim());
    
    if (isUrl) {
        detectedType.innerHTML = '<span>🔗 Detected: Website URL</span>';
        return 'url';
    } else {
        detectedType.innerHTML = '<span>💬 Detected: Text Message</span>';
        return 'text';
    }
}

/**
 * Handle example card click
 */
function handleExampleClick(e) {
    const card = e.currentTarget;
    const exampleType = card.dataset.example;
    const exampleText = examples[exampleType];
    
    if (exampleText) {
        inputText.value = exampleText;
        updateCharCount();
        
        // Scroll to input
        document.querySelector('.analysis-section').scrollIntoView({ 
            behavior: 'smooth',
            block: 'start'
        });
        
        // Highlight the input briefly
        inputText.style.borderColor = '#3b82f6';
        setTimeout(() => {
            inputText.style.borderColor = '';
        }, 1000);
        
        // Auto-analyze after a short delay
        setTimeout(() => {
            handleAnalyze();
        }, 500);
    }
}

/**
 * Handle analyze button click
 */
async function handleAnalyze() {
    const text = inputText.value.trim();
    
    // Validation
    if (!text) {
        showError('Please enter a message or URL to analyze');
        return;
    }
    
    if (text.length < 10) {
        showError('Input is too short. Please enter at least 10 characters.');
        return;
    }
    
    // Get auto-detected input type
    const inputType = detectInputType(text);
    
    // Show loading state
    showLoading();
    
    try {
        const startTime = Date.now();
        
        // Call API
        const response = await fetch('api/analyze.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                input: text,
                type: inputType
            })
        });
        
        const data = await response.json();
        
        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Analysis failed');
        }
        
        const clientTime = Date.now() - startTime;
        
        // Show results
        showResults(data.data, text);
        
    } catch (error) {
        console.error('Analysis error:', error);
        showError(error.message || 'Failed to analyze. Please try again.');
        hideLoading();
    }
}

/**
 * Show loading state
 */
function showLoading() {
    analyzeBtn.disabled = true;
    analyzeBtn.style.opacity = '0.6';
    loadingState.classList.remove('hidden');
    resultsPanel.classList.add('hidden');
}

/**
 * Hide loading state
 */
function hideLoading() {
    analyzeBtn.disabled = false;
    analyzeBtn.style.opacity = '1';
    loadingState.classList.add('hidden');
}

/**
 * Show results
 */
function showResults(data, originalText) {
    hideLoading();
    
    // Store log ID for reporting
    currentLogId = data.log_id;
    
    // Reset report button
    reportScamBtn.disabled = false;
    reportScamBtn.classList.remove('hidden');
    reportStatus.classList.add('hidden');
    reportStatus.textContent = '';
    
    // Update risk badge
    const riskBadge = document.getElementById('riskBadge');
    riskBadge.textContent = data.risk_level.toUpperCase() + ' RISK';
    riskBadge.className = 'risk-badge ' + data.risk_level;
    
    // Update scam category
    const scamCategory = document.getElementById('scamCategory');
    if (data.scam_category && data.scam_category !== 'Other' && data.scam_category !== 'None') {
        scamCategory.textContent = data.scam_category;
        scamCategory.classList.remove('hidden');
    } else {
        scamCategory.classList.add('hidden');
    }
    
    // Update risk analysis list
    const analysisList = document.getElementById('analysisList');
    analysisList.innerHTML = '';
    
    if (data.detailed_analysis && data.detailed_analysis.length > 0) {
        data.detailed_analysis.forEach(reason => {
            const li = document.createElement('li');
            li.textContent = reason;
            analysisList.appendChild(li);
        });
        document.getElementById('explanation').classList.add('hidden');
    } else {
        document.getElementById('explanation').textContent = data.explanation;
        document.getElementById('explanation').classList.remove('hidden');
    }
    
    // Update recommendation
    const recommendationBox = document.getElementById('recommendation');
    recommendationBox.innerHTML = formatAdvice(data.recommendation);
    recommendationBox.className = 'recommendation-box ' + data.risk_level;
    
    // Update indicators list
    const indicatorsList = document.getElementById('indicatorsList');
    indicatorsList.innerHTML = '';
    
    if (data.indicators && data.indicators.length > 0) {
        data.indicators.forEach(indicator => {
            const li = document.createElement('li');
            li.textContent = indicator;
            indicatorsList.appendChild(li);
        });
    } else {
        const li = document.createElement('li');
        li.textContent = 'No specific scam indicators detected';
        li.style.borderLeftColor = '#10b981';
        indicatorsList.appendChild(li);
    }
    
    // Update highlighted text
    const highlightedSection = document.getElementById('highlightedSection');
    const highlightedText = document.getElementById('highlightedText');
    
    if (data.highlighted_phrases && data.highlighted_phrases.length > 0) {
        highlightedSection.classList.remove('hidden');
        highlightedText.innerHTML = highlightPhrases(originalText, data.highlighted_phrases);
    } else {
        highlightedSection.classList.add('hidden');
    }
    
    // Update stats
    document.getElementById('riskScore').textContent = data.risk_score + '/100';
    document.getElementById('analysisTime').textContent = data.analysis_time_ms + 'ms';
    
    // Show results panel
    resultsPanel.classList.remove('hidden');
    
    // Scroll to results
    resultsPanel.scrollIntoView({ 
        behavior: 'smooth',
        block: 'nearest'
    });
}

/**
 * Highlight suspicious phrases in text
 */
function highlightPhrases(text, phrases) {
    let highlightedText = escapeHtml(text);
    
    // Sort phrases by length (longest first) to avoid partial replacements
    const sortedPhrases = [...phrases].sort((a, b) => b.length - a.length);
    
    sortedPhrases.forEach(phrase => {
        const escapedPhrase = escapeHtml(phrase);
        const regex = new RegExp(escapeRegex(escapedPhrase), 'gi');
        highlightedText = highlightedText.replace(regex, match => {
            return `<span class="highlight">${match}</span>`;
        });
    });
    
    return highlightedText;
}

/**
 * Escape HTML
 */
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

/**
 * Escape regex special characters
 */
function escapeRegex(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Show error message
 */
function showError(message) {
    // Create error toast
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: #ef4444;
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
        z-index: 1000;
        animation: slideIn 0.3s ease;
        max-width: 400px;
    `;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    // Remove after 5 seconds
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            document.body.removeChild(toast);
        }, 300);
    }, 5000);
}

/**
 * Format advice text (simple markdown-like replacement)
 */
function formatAdvice(text) {
    if (!text) return '';
    
    // Replace newlines with <br>
    let formatted = text.replace(/\r\n|\r|\n/g, '<br>');
    
    // Replace **text** with <strong>text</strong> (using s flag equivalent for multi-line bold if needed)
    formatted = formatted.replace(/\*\*((?:.|\n)*?)\*\*/g, '<strong>$1</strong>');
    
    return formatted;
}

/**
 * Reset form
 */
function resetForm() {
    inputText.value = '';
    updateCharCount();
    resultsPanel.classList.add('hidden');
    inputText.focus();
    
    // Scroll to input
    document.querySelector('.analysis-section').scrollIntoView({ 
        behavior: 'smooth',
        block: 'start'
    });
}

/**
 * Handle report scam button click
 */
async function handleReportScam() {
    if (!currentLogId) return;
    
    // Show reporting state
    reportScamBtn.disabled = true;
    reportScamBtn.innerHTML = '<span class="spinner-sm"></span> Reporting...';
    
    try {
        const response = await fetch('api/report.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                log_id: currentLogId
            })
        });
        
        const data = await response.json();
        
        if (!response.ok || !data.success) {
            throw new Error(data.error || 'Failed to report scam');
        }
        
        // Show success
        reportScamBtn.classList.add('hidden');
        reportStatus.textContent = 'Reported! Thanks for helping keep others safe. 🛡️';
        reportStatus.className = 'report-status success';
        reportStatus.classList.remove('hidden');
        
    } catch (error) {
        console.error('Report error:', error);
        reportScamBtn.disabled = false;
        reportScamBtn.innerHTML = '🚩 Report as Scam';
        
        reportStatus.textContent = 'Failed to report. Please try again.';
        reportStatus.className = 'report-status error';
        reportStatus.classList.remove('hidden');
    }
}

/**
 * Toggle Mobile Menu
 */
function toggleMenu() {
    hamburger.classList.toggle('active');
    navMenu.classList.toggle('active');
    document.body.style.overflow = navMenu.classList.contains('active') ? 'hidden' : '';
}

// Add animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
