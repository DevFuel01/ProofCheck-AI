-- ProofCheck AI Database Schema
-- Database for anonymous logging of scam analysis

CREATE DATABASE IF NOT EXISTS proofcheck_db;
USE proofcheck_db;

-- Analysis logs table (anonymous logging only)
CREATE TABLE IF NOT EXISTS analysis_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    input_type ENUM('text', 'url') NOT NULL,
    risk_level ENUM('low', 'medium', 'high') NOT NULL,
    scam_category VARCHAR(50) DEFAULT 'Other',
    risk_score INT NOT NULL,
    detected_patterns JSON,
    analysis_duration_ms INT,
    INDEX idx_timestamp (timestamp),
    INDEX idx_risk_level (risk_level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reported scams table (for community flagging)
CREATE TABLE IF NOT EXISTS reported_scams (
    id INT AUTO_INCREMENT PRIMARY KEY,
    log_id INT,
    risk_level ENUM('low', 'medium', 'high'),
    scam_category VARCHAR(50),
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (log_id) REFERENCES analysis_logs(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional: Statistics view for admin dashboard
CREATE OR REPLACE VIEW analysis_statistics AS
SELECT 
    DATE(timestamp) as analysis_date,
    input_type,
    risk_level,
    scam_category,
    COUNT(*) as total_analyses,
    AVG(risk_score) as avg_risk_score,
    AVG(analysis_duration_ms) as avg_duration_ms
FROM analysis_logs
GROUP BY DATE(timestamp), input_type, risk_level, scam_category
ORDER BY analysis_date DESC;
