<?php
require_once 'config.php';

echo "<h2>ProofCheck AI Database Diagnostic</h2>";

try {
    $pdo = getDBConnection();
    echo "<p style='color:green'>✅ Database Connection: SUCCESS</p>";

    // Check tables
    $tables = ['analysis_logs', 'reported_scams'];
    foreach ($tables as $table) {
        $stmt = $pdo->query("SELECT COUNT(*) as count FROM $table");
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'];
        echo "<p>Table <strong>$table</strong>: $count records</p>";

        if ($count > 0) {
            echo "<h4>Latest 3 records in $table:</h4>";
            $stmt = $pdo->query("SELECT * FROM $table ORDER BY id DESC LIMIT 3");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo "<pre>" . print_r($rows, true) . "</pre>";
        }
    }

    // Check column scam_category in analysis_logs
    $stmt = $pdo->query("SHOW COLUMNS FROM analysis_logs LIKE 'scam_category'");
    $col = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($col) {
        echo "<p style='color:green'>✅ Column 'scam_category' exists in analysis_logs</p>";
    } else {
        echo "<p style='color:red'>❌ Column 'scam_category' is MISSING in analysis_logs</p>";
    }
} catch (Exception $e) {
    echo "<p style='color:red'>❌ Error: " . $e->getMessage() . "</p>";
}
