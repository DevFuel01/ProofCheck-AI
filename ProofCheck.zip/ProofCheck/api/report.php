<?php

/**
 * ProofCheck AI - Report Scam API
 * Endpoint for flagging analyzed content as confirmed scams
 */

require_once __DIR__ . '/../config.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

// Get POST data
$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['log_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Missing log ID']);
    exit;
}

try {
    $db = getDBConnection();

    // Check if the log exists first
    $checkStmt = $db->prepare("SELECT risk_level, scam_category FROM analysis_logs WHERE id = ?");
    $checkStmt->execute([$data['log_id']]);
    $logData = $checkStmt->fetch(PDO::FETCH_ASSOC);

    if (!$logData) {
        http_response_code(404);
        echo json_encode(['error' => 'Analysis record not found']);
        exit;
    }

    // Insert into reported_scams (Anonymized: only referencing the log_id metadata)
    $stmt = $db->prepare("INSERT INTO reported_scams (log_id, risk_level, scam_category) VALUES (?, ?, ?)");
    $stmt->execute([
        $data['log_id'],
        $logData['risk_level'],
        $logData['scam_category'] ?? 'Other'
    ]);

    echo json_encode([
        'success' => true,
        'message' => 'Scam reported successfully. Thank you for helping keep the community safe!'
    ]);
} catch (Exception $e) {
    error_log("Reporting error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Failed to process report']);
}
