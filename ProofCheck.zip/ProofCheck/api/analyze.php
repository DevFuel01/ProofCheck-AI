<?php

/**
 * ProofCheck AI - Analysis API Endpoint
 * Handles scam detection requests
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../includes/ScamDetector.php';

// Set CORS headers
setCORSHeaders();

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Only accept POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    handleError('Method not allowed. Use POST.', 405);
}

// Get JSON input
$input = file_get_contents('php://input');
$data = json_decode($input, true);

if (json_last_error() !== JSON_ERROR_NONE) {
    handleError('Invalid JSON input', 400);
}

// Validate input
if (!isset($data['input']) || empty(trim($data['input']))) {
    handleError('Input is required', 400);
}

if (!isset($data['type']) || !in_array($data['type'], ['text', 'url'])) {
    handleError('Type must be either "text" or "url"', 400);
}

$inputText = trim($data['input']);
$inputType = $data['type'];

// Validate input length
if (strlen($inputText) > 5000) {
    handleError('Input is too long. Maximum 5000 characters.', 400);
}

try {
    // Initialize detector
    $detector = new ScamDetector(GEMINI_API_KEY);

    // Analyze input
    $results = $detector->analyze($inputText, $inputType);

    // Log analysis (anonymously)
    $logId = logAnalysis($inputType, $results);

    // Return results
    echo json_encode([
        'success' => true,
        'data' => [
            'log_id' => $logId,
            'risk_level' => $results['risk_level'],
            'risk_score' => $results['risk_score'],
            'indicators' => $results['indicators'],
            'highlighted_phrases' => $results['highlighted_phrases'],
            'explanation' => $results['explanation'],
            'recommendation' => $results['recommendation'],
            'analysis_time_ms' => $results['analysis_duration_ms']
        ]
    ]);
} catch (Exception $e) {
    error_log("Analysis error: " . $e->getMessage());
    handleError('Analysis failed. Please try again.', 500);
}

/**
 * Log analysis anonymously to database
 */
function logAnalysis($inputType, $results)
{
    try {
        $pdo = getDBConnection();

        $stmt = $pdo->prepare("
            INSERT INTO analysis_logs 
            (input_type, risk_level, risk_score, detected_patterns, analysis_duration_ms)
            VALUES (?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $inputType,
            $results['risk_level'],
            $results['risk_score'],
            json_encode([
                'indicators' => $results['indicators'],
                'phrase_count' => count($results['highlighted_phrases'])
            ]),
            $results['analysis_duration_ms']
        ]);

        return $pdo->lastInsertId();
    } catch (Exception $e) {
        // Log error but don't fail the request
        error_log("Failed to log analysis: " . $e->getMessage());
        return null;
    }
}
