<?php
require_once __DIR__ . '/../config.php';

// Fetch aggregate statistics from the database
try {
    $db = getDBConnection();

    // Total checks
    $totalStmt = $db->query("SELECT COUNT(*) as total FROM analysis_logs");
    $totalChecks = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

    // Risk distribution
    $riskStmt = $db->query("SELECT risk_level, COUNT(*) as count FROM analysis_logs GROUP BY risk_level");
    $riskData = $riskStmt->fetchAll(PDO::FETCH_ASSOC);

    $distribution = [
        'low' => 0,
        'medium' => 0,
        'high' => 0
    ];

    foreach ($riskData as $row) {
        $distribution[$row['risk_level']] = (int)$row['count'];
    }

    // Recent activity (last 10)
    $recentStmt = $db->query("SELECT timestamp, input_type, risk_level, risk_score FROM analysis_logs ORDER BY timestamp DESC LIMIT 10");
    $recentActivity = $recentStmt->fetchAll(PDO::FETCH_ASSOC);

    // Total reported scams
    $reportStmt = $db->query("SELECT COUNT(*) as total FROM reported_scams");
    $totalReports = $reportStmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;
} catch (Exception $e) {
    error_log("Dashboard error: " . $e->getMessage());
    $totalChecks = 0;
    $totalReports = 0;
    $distribution = ['low' => 0, 'medium' => 0, 'high' => 0];
    $recentActivity = [];
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | ProofCheck AI</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --admin-bg: #0f172a;
            --card-bg: #1e293b;
        }

        body {
            background-color: var(--admin-bg);
            padding-top: 0;
        }

        .admin-nav {
            background: var(--card-bg);
            padding: 1rem 2rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .dashboard-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 0 1rem;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 2rem;
        }

        .stat-card {
            background: var(--card-bg);
            padding: 1.5rem;
            border-radius: 12px;
            border: 1px solid var(--border-color);
            transition: transform 0.2s;
        }

        .stat-card:hover {
            transform: translateY(-4px);
        }

        .stat-label {
            color: var(--text-secondary);
            font-size: 0.875rem;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 0.5rem;
        }

        .stat-value {
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--primary-color);
        }

        .distribution-card {
            background: var(--card-bg);
            padding: 2rem;
            border-radius: 12px;
            border: 1px solid var(--border-color);
            margin-bottom: 2rem;
        }

        .dist-item {
            margin-bottom: 1.5rem;
        }

        .dist-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 0.5rem;
        }

        .dist-bar-bg {
            height: 12px;
            background: #334155;
            border-radius: 6px;
            overflow: hidden;
        }

        .dist-bar-fill {
            height: 100%;
            border-radius: 6px;
            transition: width 1s ease-out;
        }

        .fill-low {
            background: var(--risk-low);
        }

        .fill-medium {
            background: var(--risk-medium);
        }

        .fill-high {
            background: var(--risk-high);
        }

        .table-container {
            background: var(--card-bg);
            border-radius: 12px;
            border: 1px solid var(--border-color);
            overflow: hidden;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
        }

        th {
            background: rgba(255, 255, 255, 0.05);
            padding: 1rem;
            color: var(--text-secondary);
            font-weight: 600;
            font-size: 0.875rem;
        }

        td {
            padding: 1rem;
            border-bottom: 1px solid var(--border-color);
            font-size: 0.875rem;
        }

        .risk-tag {
            padding: 0.25rem 0.5rem;
            border-radius: 4px;
            font-size: 0.75rem;
            font-weight: 600;
            text-transform: uppercase;
        }

        .tag-low {
            background: rgba(16, 185, 129, 0.1);
            color: #10b981;
        }

        .tag-medium {
            background: rgba(245, 158, 11, 0.1);
            color: #f59e0b;
        }

        .tag-high {
            background: rgba(239, 68, 68, 0.1);
            color: #ef4444;
        }

        .privacy-banner {
            background: rgba(59, 130, 246, 0.1);
            color: var(--primary-color);
            padding: 1rem;
            border-radius: 8px;
            border: 1px solid rgba(59, 130, 246, 0.2);
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
    </style>
</head>

<body>
    <nav class="admin-nav">
        <div class="nav-brand">
            <span style="font-weight: 700; font-size: 1.25rem; color: var(--primary-color);">ProofCheck AI</span>
            <span style="color: var(--text-secondary); margin-left: 0.5rem;">Admin Analytics</span>
        </div>
        <a href="../index.php" class="secondary-btn" style="padding: 0.5rem 1rem; font-size: 0.875rem;">Back to App</a>
    </nav>

    <div class="dashboard-container">
        <div class="privacy-banner">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path>
            </svg>
            <span><strong>Privacy Guard Active:</strong> No message content is stored in this database. Dashboard shows anonymous aggregate metadata only.</span>
        </div>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-label">Total Checks Performed</div>
                <div class="stat-value"><?php echo number_format($totalChecks); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">Total Reported Scams</div>
                <div class="stat-value" style="color: var(--danger);"><?php echo number_format($totalReports); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-label">System Status</div>
                <div class="stat-value" style="color: #10b981; font-size: 1.5rem;">Online & Secure</div>
            </div>
        </div>

        <div class="distribution-card">
            <h3 style="margin-bottom: 1.5rem;">Global Risk Distribution</h3>
            <?php
            $maxCount = max($distribution) ?: 1;
            foreach (['high', 'medium', 'low'] as $level):
                $count = $distribution[$level];
                $percentage = round(($count / ($totalChecks ?: 1)) * 100);
            ?>
                <div class="dist-item">
                    <div class="dist-header">
                        <span style="text-transform: capitalize; font-weight: 600;"><?php echo $level; ?> Risk</span>
                        <span style="color: var(--text-secondary);"><?php echo $count; ?> checks (<?php echo $percentage; ?>%)</span>
                    </div>
                    <div class="dist-bar-bg">
                        <div class="dist-bar-fill fill-<?php echo $level; ?>" style="width: <?php echo $percentage; ?>%"></div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="recent-section">
            <h3 style="margin-bottom: 1rem;">Recent Activity (Anonymous)</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Time</th>
                            <th>Type</th>
                            <th>Risk Level</th>
                            <th>Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($recentActivity)): ?>
                            <tr>
                                <td colspan="4" style="text-align: center; padding: 2rem; color: var(--text-secondary);">No activity recorded yet.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recentActivity as $activity): ?>
                                <tr>
                                    <td><?php echo date('M j, H:i', strtotime($activity['timestamp'])); ?></td>
                                    <td style="text-transform: capitalize;"><?php echo $activity['input_type']; ?></td>
                                    <td><span class="risk-tag tag-<?php echo $activity['risk_level']; ?>"><?php echo $activity['risk_level']; ?></span></td>
                                    <td style="font-weight: 600;"><?php echo $activity['risk_score']; ?>%</td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>

</html>