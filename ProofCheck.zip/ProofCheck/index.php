<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="ProofCheck AI - Instantly detect scam messages, phishing links, and fraud attempts before you lose money">
    <title>ProofCheck AI - Scam Detection System</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
</head>

<body>
    <!-- Header -->
    <header class="header">
        <div class="container">
            <div class="header-content">
                <div class="logo">
                    <span class="logo-icon">🛡️</span>
                    <span class="logo-text">ProofCheck AI</span>
                </div>
                <nav class="nav" id="navMenu">
                    <a href="#how-it-works" class="nav-link">How It Works</a>
                    <a href="#examples" class="nav-link">Examples</a>
                    <a href="#privacy" class="nav-link">Privacy</a>
                </nav>
                <button class="hamburger" id="hamburger" aria-label="Toggle Navigation">
                    <span class="bar"></span>
                    <span class="bar"></span>
                    <span class="bar"></span>
                </button>
            </div>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <div class="container">
            <div class="hero-content">
                <h1 class="hero-title">Stop Scams Before They Stop You</h1>
                <p class="hero-subtitle">Instantly detect scam messages, phishing links, and fraud attempts with AI-powered analysis</p>
                <div class="hero-stats">
                    <div class="stat">
                        <span class="stat-number">99%</span>
                        <span class="stat-label">Detection Rate</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">&lt;5s</span>
                        <span class="stat-label">Analysis Time</span>
                    </div>
                    <div class="stat">
                        <span class="stat-number">100%</span>
                        <span class="stat-label">Private</span>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Main Analysis Section -->
    <section class="analysis-section">
        <div class="container">
            <div class="analysis-card">
                <h2 class="section-title">Analyze Suspicious Content</h2>
                <p class="section-subtitle">Paste any message or URL below - we'll automatically detect the type</p>

                <!-- Input Area -->
                <div class="input-container">
                    <textarea
                        id="inputText"
                        class="input-field"
                        placeholder="Paste suspicious message or URL here (SMS, WhatsApp, email, or website link)..."
                        rows="6"
                        maxlength="5000"></textarea>
                    <div class="input-footer">
                        <span id="detectedType" class="detected-type"></span>
                        <span class="char-count"><span id="charCount">0</span>/5000</span>
                    </div>
                </div>

                <!-- Analyze Button -->
                <button id="analyzeBtn" class="btn-analyze">
                    <span class="btn-text">Analyze Now</span>
                    <span class="btn-icon">🔍</span>
                </button>

                <!-- Loading State -->
                <div id="loadingState" class="loading-state hidden">
                    <div class="loading-spinner"></div>
                    <p class="loading-text">Analyzing for scam indicators...</p>
                </div>

                <!-- Results Panel -->
                <div id="resultsPanel" class="results-panel hidden">
                    <div class="results-header">
                        <h3 class="results-title">Analysis Results</h3>
                        <div class="header-badges">
                            <div id="riskBadge" class="risk-badge"></div>
                            <div id="scamCategory" class="scam-category-label hidden"></div>
                        </div>
                    </div>

                    <div class="results-content">
                        <!-- Explanation -->
                        <div class="result-section">
                            <h4 class="result-section-title">Risk Analysis</h4>
                            <ul id="analysisList" class="analysis-list"></ul>
                            <p id="explanation" class="explanation-text hidden"></p>
                        </div>

                        <!-- Recommendation -->
                        <div class="result-section">
                            <h4 class="result-section-title">Recommendation</h4>
                            <div id="recommendation" class="recommendation-box"></div>
                        </div>

                        <!-- Detected Indicators -->
                        <div class="result-section">
                            <h4 class="result-section-title">Detected Indicators</h4>
                            <ul id="indicatorsList" class="indicators-list"></ul>
                        </div>

                        <!-- Highlighted Text -->
                        <div class="result-section" id="highlightedSection">
                            <h4 class="result-section-title">Suspicious Phrases</h4>
                            <div id="highlightedText" class="highlighted-text"></div>
                        </div>

                        <!-- Analysis Stats -->
                        <div class="result-section">
                            <div class="analysis-stats">
                                <div class="stat-item">
                                    <span class="stat-label">Risk Score</span>
                                    <span id="riskScore" class="stat-value">-</span>
                                </div>
                                <div class="stat-item">
                                    <span class="stat-label">Analysis Time</span>
                                    <span id="analysisTime" class="stat-value">-</span>
                                </div>
                            </div>
                        </div>

                        <!-- Actions -->
                        <div class="results-actions">
                            <button id="reportScamBtn" class="btn-report">
                                <span class="btn-icon">🚩</span> Report as Scam
                            </button>
                            <span id="reportStatus" class="report-status hidden"></span>
                        </div>
                    </div>

                    <button id="analyzeAgainBtn" class="btn-secondary">Analyze Another Message</button>
                </div>
            </div>
        </div>
    </section>

    <!-- How It Works Section -->
    <section id="how-it-works" class="how-it-works">
        <div class="container">
            <h2 class="section-title">How It Works</h2>
            <div class="features-grid">
                <div class="feature-card">
                    <div class="feature-icon">🤖</div>
                    <h3 class="feature-title">AI-Powered Analysis</h3>
                    <p class="feature-description">Advanced NLP algorithms detect sophisticated scam patterns and social engineering tactics</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">⚡</div>
                    <h3 class="feature-title">Rule-Based Detection</h3>
                    <p class="feature-description">Instant pattern matching for known scam indicators like urgency tactics and suspicious URLs</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🎯</div>
                    <h3 class="feature-title">Hybrid Approach</h3>
                    <p class="feature-description">Combines AI intelligence with rule-based speed for accurate and fast scam detection</p>
                </div>
                <div class="feature-card">
                    <div class="feature-icon">🔒</div>
                    <h3 class="feature-title">Privacy First</h3>
                    <p class="feature-description">No personal data stored. All analysis is temporary and completely anonymous</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Examples Section -->
    <section id="examples" class="examples-section">
        <div class="container">
            <h2 class="section-title">Try These Examples</h2>
            <p class="section-subtitle">Click any example to analyze it instantly</p>
            <div class="examples-grid">
                <div class="example-card" data-example="safe">
                    <div class="example-header">
                        <span class="example-badge low">Safe</span>
                        <span class="example-type">Legitimate</span>
                    </div>
                    <p class="example-text">Hey! Just wanted to check if we are still on for dinner tonight at 7 PM? Let me know when you can!</p>
                </div>
                <div class="example-card" data-example="url_scam">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">URL Phishing</span>
                    </div>
                    <p class="example-text">Security Alert: Abnormal login detected on your Paypa1 account. Please secure your account immediately: http://paypa1-security-check.com/login</p>
                </div>
                <div class="example-card" data-example="urgent">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">SMS Scam</span>
                    </div>
                    <p class="example-text">URGENT! Your bank account has been suspended due to unusual activity. Click here immediately to verify your identity: bit.ly/verify123</p>
                </div>
                <div class="example-card" data-example="prize">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">Prize Scam</span>
                    </div>
                    <p class="example-text">Congratulations! You've won $5,000 in our lottery draw! To claim your prize, send us your bank details and a processing fee of $50. Limited time offer!</p>
                </div>
                <div class="example-card" data-example="otp">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">OTP Phishing</span>
                    </div>
                    <p class="example-text">Dear customer, we need to verify your account. Please reply with the OTP code we just sent to your phone to avoid account suspension.</p>
                </div>
                <div class="example-card" data-example="authority">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">Authority Scam</span>
                    </div>
                    <p class="example-text">This is the IRS. You have unpaid taxes. Failure to respond within 48 hours will result in legal action and arrest warrant. Call immediately: 555-0123</p>
                </div>
                <div class="example-card" data-example="delivery">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">Fake Delivery</span>
                    </div>
                    <p class="example-text">Your package delivery failed. Pay $3.99 shipping fee to reschedule: http://fedex-delivery-track.com/confirm. Your package will be returned if not claimed within 24 hours.</p>
                </div>
                <div class="example-card" data-example="tech">
                    <div class="example-header">
                        <span class="example-badge high">High Risk</span>
                        <span class="example-type">Tech Support Scam</span>
                    </div>
                    <p class="example-text">Microsoft Security Alert: We detected suspicious activity on your computer. Your system may be infected with malware. Call our certified technicians immediately at 1-800-SUPPORT to prevent data loss.</p>
                </div>
                <div class="example-card" data-example="investment">
                    <div class="example-header">
                        <span class="example-badge medium">Medium Risk</span>
                        <span class="example-type">Investment Scam</span>
                    </div>
                    <p class="example-text">Urgently hiring! Part-time remote work. Earn up to $400 daily. No interview required. Act now! Telegram @JobManager_Verify or http://bit.ly/fast-job-now</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Privacy Section -->
    <section id="privacy" class="privacy-section">
        <div class="container">
            <div class="privacy-card">
                <h2 class="section-title">Privacy & Data Protection</h2>
                <p class="section-subtitle">Your security and trust are our top priorities</p>
                <div class="privacy-content">
                    <div class="privacy-item">
                        <span class="privacy-icon">🛡️</span>
                        <div class="privacy-text">
                            <h4>No Personal Data Stored</h4>
                            <p>We do not store your messages, URLs, or any personally identifiable information. Your privacy is guaranteed by design.</p>
                        </div>
                    </div>
                    <div class="privacy-item">
                        <span class="privacy-icon">⚡</span>
                        <div class="privacy-text">
                            <h4>Temporary Processing</h4>
                            <p>All input is processed temporarily for analysis and as such is discarded immediately after results are delivered.</p>
                        </div>
                    </div>
                    <div class="privacy-item">
                        <span class="privacy-icon">🤝</span>
                        <div class="privacy-text">
                            <h4>Built for Trust</h4>
                            <p>Our hybrid detection system is designed to provide responsible AI analysis while ensuring you remain in control of your data.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <span class="logo-icon">🛡️</span>
                    <span class="logo-text">ProofCheck AI</span>
                </div>
                <p class="footer-text">Protecting users from scams with AI-powered detection</p>
                <p class="footer-copyright">&copy; 2026 ProofCheck AI. Built for safety and privacy.</p>
            </div>
        </div>
    </footer>

    <script src="assets/js/app.js"></script>
</body>

</html>